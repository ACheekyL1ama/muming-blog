import{t as o}from"./ProgressIndicator.DAhxXkM0.js";export{o as default};
