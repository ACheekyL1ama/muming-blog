import"./chunk-FOHPRMQF.RiINRNTM.js";import{O as t}from"./mermaid-parser.core.Cez0fNpu.js";export{t as createEventModelingServices};
