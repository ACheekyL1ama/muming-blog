import{t as o}from"./LoadingIndicator.CqN96Uyy.js";export{o as default};
