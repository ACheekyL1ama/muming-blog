import"./chunk-FOHPRMQF.RiINRNTM.js";import{w as t}from"./mermaid-parser.core.Cez0fNpu.js";export{t as createInfoServices};
