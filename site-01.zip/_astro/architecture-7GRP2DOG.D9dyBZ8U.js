import"./chunk-FOHPRMQF.RiINRNTM.js";import{M as t}from"./mermaid-parser.core.Cez0fNpu.js";export{t as createArchitectureServices};
