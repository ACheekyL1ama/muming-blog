import"./chunk-FOHPRMQF.RiINRNTM.js";import{o}from"./mermaid-parser.core.Cez0fNpu.js";export{o as createTreemapServices};
