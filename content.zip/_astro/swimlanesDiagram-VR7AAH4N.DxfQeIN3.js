import{n as r}from"./chunk-Y2CYZVJY.CrVYBJys.js";import"./src.DMyboxQk.js";import"./chunk-DU6HZSFF.DMv4tjVi.js";import"./chunk-75Z2AOVW.LQ6JkRm_.js";import"./chunk-PWAF6VOD.DGcXIIPR.js";import"./chunk-GMAD6QVW.D8m79LUf.js";import"./chunk-P2QGCYS3.3CBPKSsq.js";import"./chunk-4HAMMTFA.suJ7WgLc.js";import"./chunk-GVQU2GXP.wFxQRWEo.js";import"./chunk-OSK3NFVY.DD78F7Es.js";import"./chunk-F27PBJKO.BLlZEJG4.js";import"./chunk-XXDRQBXY.CvRrnCQ1.js";import"./chunk-POPQ4Y6H.BlyikDu8.js";import"./chunk-L3NEJ4N5.PdT0LTCG.js";import{r as o,t as m}from"./chunk-SHT3W25Y.DLQXcAQb.js";import"./mermaid.core.DyTO04RW.js";var $=m({defaultLayout:"swimlane",styles:r(t=>`${o(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles")});export{$ as diagram};
