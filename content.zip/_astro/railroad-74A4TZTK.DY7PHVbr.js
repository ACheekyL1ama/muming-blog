import"./chunk-FOHPRMQF.RiINRNTM.js";import{g as o}from"./mermaid-parser.core.Cez0fNpu.js";export{o as createRailroadServices};
