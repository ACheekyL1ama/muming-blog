import{t as o}from"./LoadingIndicator.BVTF8pS8.js";export{o as default};
