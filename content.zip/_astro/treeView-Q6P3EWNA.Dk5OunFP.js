import"./chunk-FOHPRMQF.RiINRNTM.js";import{c as i}from"./mermaid-parser.core.Cez0fNpu.js";export{i as createTreeViewServices};
