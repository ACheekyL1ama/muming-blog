import"./chunk-FOHPRMQF.RiINRNTM.js";import{f as e}from"./mermaid-parser.core.Cez0fNpu.js";export{e as createRailroadEbnfServices};
