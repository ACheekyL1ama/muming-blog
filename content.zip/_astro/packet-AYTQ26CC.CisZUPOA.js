import"./chunk-FOHPRMQF.RiINRNTM.js";import{S as t}from"./mermaid-parser.core.Cez0fNpu.js";export{t as createPacketServices};
